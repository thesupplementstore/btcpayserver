﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BTCPayServer.Vault.HWI
{
    public class HwiServerOptions
    {
        public string HwiDeploymentDirectory { get; set; } = ".";
    }
}
