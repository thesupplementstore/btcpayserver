﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BTCPayServer.Vault
{
    public class RateLimitZones
    {
        public const string Prompt = nameof(Prompt);
    }
}
