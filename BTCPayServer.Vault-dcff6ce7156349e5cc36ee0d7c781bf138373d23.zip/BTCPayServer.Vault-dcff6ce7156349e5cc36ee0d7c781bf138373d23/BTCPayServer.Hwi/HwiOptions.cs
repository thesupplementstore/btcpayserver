using System;
using System.Collections.Generic;
using System.Text;

namespace BTCPayServer.Hwi
{
	internal enum HwiOptions
	{
		Help,
		DevicePath,
		DeviceType,
		Password,
		StdInPass,
		TestNet,
		Debug,
		Version,
		StdIn,
		Interactive
	}
}
