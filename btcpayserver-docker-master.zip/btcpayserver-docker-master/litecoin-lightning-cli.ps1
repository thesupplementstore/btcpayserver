docker exec btcpayserver_clightning_litecoin lightning-cli $args
