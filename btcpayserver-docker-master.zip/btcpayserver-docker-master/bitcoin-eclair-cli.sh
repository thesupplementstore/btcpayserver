#!/bin/bash

docker exec btcpayserver_eclair_bitcoin eclair-cli -p DwubwWsoo3 "$@"
