#!/bin/bash

dotnet run --no-launch-profile -c Release -- $@