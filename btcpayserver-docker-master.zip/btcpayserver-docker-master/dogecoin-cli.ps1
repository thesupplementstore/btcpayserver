docker exec btcpayserver_dogecoind dogecoin-cli -datadir="/data" $args
