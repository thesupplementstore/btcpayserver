docker exec btcpayserver_bgoldd bgold-cli -datadir="/data" $args
