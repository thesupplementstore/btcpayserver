#!/bin/bash

docker exec btcpayserver_lnd_groestlcoin lncli "$@"
