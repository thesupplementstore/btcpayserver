#!/bin/bash

docker exec btcpayserver_clightning_litecoin lightning-cli "$@"
