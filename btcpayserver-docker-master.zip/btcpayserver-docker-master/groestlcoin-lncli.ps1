docker exec btcpayserver_lnd_groestlcoin lncli $args
