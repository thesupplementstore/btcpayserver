#!/bin/bash

docker exec btcpayserver_clightning_groestlcoin lightning-cli "$@"
