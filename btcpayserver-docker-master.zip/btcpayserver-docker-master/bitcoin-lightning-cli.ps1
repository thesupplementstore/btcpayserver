docker exec btcpayserver_clightning_bitcoin lightning-cli $args
