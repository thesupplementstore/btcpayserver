#!/bin/bash

docker exec pihole pihole "$@"
