# Dev script for bumping the stable branch
git checkout stable; git rebase master; git push; git checkout master