docker exec btcpayserver_bitcored bitcore-cli -datadir="/data" $args
