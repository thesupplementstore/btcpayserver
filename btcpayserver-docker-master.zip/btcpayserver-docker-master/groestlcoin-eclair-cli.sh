#!/bin/bash

docker exec btcpayserver_eclair_groestlcoin eclair-cli -p DwubwWsoo3 "$@"
