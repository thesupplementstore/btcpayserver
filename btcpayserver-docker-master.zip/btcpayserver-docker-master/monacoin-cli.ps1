docker exec btcpayserver_monacoind monacoin-cli -datadir="/data" $args
