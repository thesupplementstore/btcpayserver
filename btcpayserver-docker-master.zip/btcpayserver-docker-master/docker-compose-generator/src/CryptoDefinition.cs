﻿namespace DockerGenerator
{
	public class CryptoDefinition
	{
		public string Crypto { get; set; }
		public string CryptoFragment { get; set; }
		public string CLightningFragment { get; set; }
		public string LNDFragment { get; set; }
		public string EclairFragment { get; set; }
	}
}