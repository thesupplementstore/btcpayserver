docker exec btcpayserver_dashd dash-cli -datadir="/data" $args
