docker exec btcpayserver_litecoind litecoin-cli -datadir="/data" $args
