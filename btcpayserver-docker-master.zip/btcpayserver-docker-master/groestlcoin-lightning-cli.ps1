docker exec btcpayserver_clightning_groestlcoin lightning-cli $args
